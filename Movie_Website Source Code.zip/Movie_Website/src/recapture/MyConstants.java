package recapture;

class MyConstants {


    public static final String SITE_KEY ="6LecnUcUAAAAADv0ZNNlWN0-SldYHvBtVjokjCAK";
    
    

    public static final String SECRET_KEY ="6LecnUcUAAAAAPhzsrPxWCFz-PO2tDqOvSbPrLTS";

}

